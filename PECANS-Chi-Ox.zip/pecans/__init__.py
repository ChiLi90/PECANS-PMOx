"""
PECANS: Python Editable Chemical Atmospheric Numeric Solver
"""