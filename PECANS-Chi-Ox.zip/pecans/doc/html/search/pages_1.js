var searchData=
[
  ['getting_20started',['Getting started',['../md_additional_2-getting-started.html',1,'']]]
];
