var searchData=
[
  ['changed_5fspecie',['changed_specie',['../classpecans_1_1mechgen_1_1Derivative.html#a8e0a1ede8e4d02582dda60aa2738c4b7',1,'pecans::mechgen::Derivative']]],
  ['coefficients',['coefficients',['../classpecans_1_1mechgen_1_1Derivative.html#ad5d2c9c575a5f73dd1e8df55bde0b149',1,'pecans::mechgen::Derivative']]]
];
