PECANS Core
===========

.. include:: includes/top_includes.rst

.. automodule:: pecans.core
   :members:
