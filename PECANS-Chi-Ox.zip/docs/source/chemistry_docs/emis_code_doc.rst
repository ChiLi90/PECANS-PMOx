Emissions schemes
=================

.. automodule:: pecans.emissions.emissions_setup
   :members: