Chemistry solvers
=================

Setup and initialization
------------------------

.. automodule:: pecans.chemistry.chem_setup
   :members:


.. _ideal_chem_mech_code:

Ideal chemical mechanisms
-------------------------

.. automodule:: pecans.chemistry.ideal
   :members: